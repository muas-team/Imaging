%% Shape Distinctions
X = imread('circle.tif');
I = X(1:end, 1:end, 1:3);
I = rgb2gray(X);
I2 = imadjust(I,[0;1], [1;0]);
% figure
% imshow(I2)
I2 = im2bw(I2);
% I3 = bwconncomp(I2);

% Pulling out boundary points
figure
[B,L,N,A] = bwboundaries(I2);
stat = regionprops(I2, 'Centroid');
cent = stat.Centroid;
boundary = B{1};
subplot(2,2,1)
hold on
plot(boundary(:,2), boundary(:,1), 'b', 'LineWidth', 1)
plot(cent(1),cent(2), 'g+')
axis([0 length(I(1,:)) 0 length(I(:,1))])
hold off

% Finding Distances from Centroid
distPlot = [];
for i = 1:length(boundary)
%     distPlot = [distPlot cast(sqrt((cent(1)-boundary(i,1))^2 + (cent(2)-boundary(i,2))^2),'int32')];
    distPlot = [distPlot sqrt((cent(1)-boundary(i,1))^2 + (cent(2)-boundary(i,2))^2)]; 
    % does not cast data to integer for use later with findpeaks
end
subplot(2,2,2)
hold on
plot(distPlot)
axis([0 length(boundary) 0 1000])
hold off

% Showing the initial shape
subplot(2,2,3)
imshow(I);

% Shape Comparisons

[maxs locs] = findpeaks(distPlot,'MinPeakDistance',cast(length(boundary)/20,'int16'));
subplot(2,2,4)
plot(locs, maxs, 'r+')